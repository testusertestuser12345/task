#!/bin/sh
set -e

mkdir -p /run/named
chown bind:bind /run/named /var/lib/bind /var/cache/bind

# 起動時に現在の分に合わせたゾーンを生成
/usr/local/bin/switcher.sh --once

# 構文チェック
named-checkconf
named-checkzone example.com /var/lib/bind/db.example.com
named-checkzone 0.16.172.in-addr.arpa /etc/bind/zones/db.172.16.0

# 切り替えループをバックグラウンドで起動
/usr/local/bin/switcher.sh &

# BIND をフォアグラウンドで起動
exec /usr/sbin/named -u bind -g
