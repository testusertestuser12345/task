#!/bin/sh
# hogehoge.example.com の A レコードを分の切り替わりで厳密に入れ替える
#   偶数分 -> 172.16.0.40 (nginx)
#   奇数分 -> 172.16.0.30 (Apache)

TMPL=/etc/bind/zones/db.example.com.tmpl
ZONE=/var/lib/bind/db.example.com

render() {
    now=$(date +%s)
    if [ $(( (now / 60) % 2 )) -eq 0 ]; then ip=172.16.0.40; else ip=172.16.0.30; fi
    sed -e "s/__SERIAL__/${now}/" -e "s/__HOGEHOGE_IP__/${ip}/" "$TMPL" > "${ZONE}.tmp"
    mv "${ZONE}.tmp" "$ZONE"
    chown bind:bind "$ZONE"
    echo "[switcher] $(date '+%F %T') hogehoge.example.com -> ${ip}"
}

if [ "$1" = "--once" ]; then
    render
    exit 0
fi

while true; do
    # 次の分の 00 秒まで待つ
    sec=$(date +%s)
    sleep $(( 60 - sec % 60 ))
    render
    rndc reload example.com >/dev/null 2>&1 || echo "[switcher] rndc reload failed"
done
