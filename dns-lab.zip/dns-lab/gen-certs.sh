#!/bin/sh
# 自前CAと各サーバ証明書を作成する
# docker compose の certgen コンテナから自動実行される (既にあれば何もしない)
set -e

CERT_DIR=${CERT_DIR:-./certs}
CA_DIR=$CERT_DIR/ca
SV_DIR=$CERT_DIR/server
mkdir -p "$CA_DIR" "$SV_DIR"

# ---- CA ----
if [ ! -f "$CA_DIR/ca.crt" ] || [ ! -f "$CA_DIR/ca.key" ]; then
    openssl req -x509 -newkey rsa:2048 -nodes -sha256 -days 3650 \
        -keyout "$CA_DIR/ca.key" -out "$CA_DIR/ca.crt" \
        -subj "/C=JP/O=DNS Lab/CN=DNS Lab Root CA"
    chmod 644 "$CA_DIR/ca.crt"
    echo "[+] CA created"
fi

# ---- サーバ証明書 ----
# make_cert <ファイル名> <CN> <SAN>
make_cert() {
    name=$1; cn=$2; san=$3
    if [ -f "$SV_DIR/$name.crt" ] && [ -f "$SV_DIR/$name.key" ]; then
        echo "[=] $name (exists)"
        return
    fi
    ext="$SV_DIR/$name.ext"
    printf "subjectAltName=%s\nkeyUsage=digitalSignature,keyEncipherment\nextendedKeyUsage=serverAuth\n" "$san" > "$ext"
    openssl req -newkey rsa:2048 -nodes -sha256 \
        -keyout "$SV_DIR/$name.key" -out "$SV_DIR/$name.csr" \
        -subj "/C=JP/O=DNS Lab/CN=$cn"
    openssl x509 -req -in "$SV_DIR/$name.csr" -sha256 -days 825 \
        -CA "$CA_DIR/ca.crt" -CAkey "$CA_DIR/ca.key" -CAcreateserial \
        -extfile "$ext" -out "$SV_DIR/$name.crt"
    rm -f "$SV_DIR/$name.csr" "$ext"
    chmod 644 "$SV_DIR/$name.key" "$SV_DIR/$name.crt"
    echo "[+] $name"
}

make_cert web.example.com      web.example.com      "DNS:web.example.com,IP:172.16.0.10"
make_cert hogefuga.example.com hoge.example.com     "DNS:hoge.example.com,DNS:fuga.example.com,IP:172.16.0.20"
make_cert hogehoge.example.com hogehoge.example.com "DNS:hogehoge.example.com,IP:172.16.0.30,IP:172.16.0.40"

echo "certs ready: $CA_DIR/ca.crt"
