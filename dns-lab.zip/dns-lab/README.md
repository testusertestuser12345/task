# DNS Lab (Kali + Docker)

| IP | FQDN | サーバ | ポート | DNS |
|---|---|---|---|---|
| 172.16.0.53 | ns.example.com | BIND | 53 | A / PTR |
| 172.16.0.10 | web.example.com | nginx | 443 | A / PTR |
| 172.16.0.20 | hoge, fuga.example.com | nginx | 80→443 | A×2 / PTR×2(hoge, fuga) |
| 172.16.0.30 | hogehoge.example.com | Apache | 443 | 奇数分に応答 / PTR |
| 172.16.0.40 | hogehoge.example.com | nginx | 443 | 偶数分に応答 / PTR |
| 172.16.0.50 | - (IPのみ) | Apache | 80 | 登録なし |
| 172.16.0.60 | test.example.com (FQDNのみ) | Apache | 80 | 登録なし |

## 使い方
```bash
sudo apt install -y docker.io docker-compose dnsutils curl   # 未導入なら
sudo systemctl enable --now docker
unzip dns-lab.zip && cd dns-lab
sudo docker compose up -d --build   # 証明書作成 → ビルド → 全コンテナ起動
./test.sh                           # 動作確認
```

## よく使うコマンド
```bash
dig @172.16.0.53 web.example.com
dig @172.16.0.53 -x 172.16.0.10
watch -n 5 dig +short @172.16.0.53 hogehoge.example.com   # 切替の確認
docker logs -f dns                                         # 切替ログ
docker compose down                                        # 停止
```

## ブラウザで見る場合
`certs/ca/ca.crt` をブラウザの「認証局」にインポートすると警告が消えます。

## 証明書について
`docker compose up` 時に `certgen` コンテナが `certs/` に証明書を自動作成して終了します
(既にあれば作り直しません)。作り直したいときは `sudo rm -rf certs/*` してから再度 up してください。
