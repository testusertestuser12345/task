#!/bin/bash
# 動作確認 (Kali の DNS 設定は変えずに @172.16.0.53 を直接指定)
cd "$(dirname "$0")"
DNS=172.16.0.53
CA=certs/ca/ca.crt

hr() { echo; echo "===== $* ====="; }
q()  { dig +short @"$DNS" "$@"; }

hr "正引き"
for n in ns web hoge fuga hogehoge test; do
    printf "%-22s -> %s\n" "$n.example.com" "$(q $n.example.com A | tr '\n' ' ')"
done

hr "逆引き"
for ip in 53 10 20 30 40 50 60; do
    printf "%-14s -> %s\n" "172.16.0.$ip" "$(q -x 172.16.0.$ip | tr '\n' ' ')"
done

hr "web.example.com (443のみ)"
IP=$(q web.example.com)
curl -s --cacert $CA --resolve web.example.com:443:$IP https://web.example.com/ | grep -o '<h1>.*</h1>'
curl -s -m 3 -o /dev/null -w "HTTP 80 -> %{http_code} (000=接続不可でOK)\n" http://$IP/

hr "hoge / fuga (80→443リダイレクト)"
IP=$(q hoge.example.com)
for n in hoge fuga; do
    curl -s -o /dev/null -w "http://$n -> %{http_code} %{redirect_url}\n" \
        --resolve $n.example.com:80:$IP http://$n.example.com/
    curl -s --cacert $CA --resolve $n.example.com:443:$IP https://$n.example.com/ | grep -o '<h1>.*</h1>'
done

hr "172.16.0.50 (IPのみ)"
curl -s http://172.16.0.50/ | grep -o '<h1>.*</h1>'

hr "test.example.com (FQDNのみ・DNS未登録)"
echo "DNS応答: '$(q test.example.com)' (空ならOK)"
curl -s -H "Host: test.example.com" http://172.16.0.60/ | grep -o '<h1>.*</h1>'

hr "hogehoge.example.com (1分ごとに切替)"
IP=$(q hogehoge.example.com)
echo "$(date '+%T') -> $IP"
curl -s --cacert $CA --resolve hogehoge.example.com:443:$IP https://hogehoge.example.com/ | grep -o '<h1>.*</h1>'
