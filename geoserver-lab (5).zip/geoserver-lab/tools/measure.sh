#!/usr/bin/env bash
# GeoServer コンテナのシェル内から TLS 計測対象の
# JARM 値と SSL 証明書 SHA256 ハッシュを取得する。
#
# sidecar は geoserver と同じネットワーク名前空間なので 8443 は localhost に見える。
# 使い方:  bash /opt/tools/measure.sh [IP] [PORT]
# 既定:    127.0.0.1  8443   (ホストから計測する場合は <ホストIP> 8443)
set -e

TARGET_IP="${1:-127.0.0.1}"
TARGET_PORT="${2:-8443}"

# 依存ツールを用意 (GeoServer公式イメージは Debian系, root実行)
if ! command -v openssl >/dev/null 2>&1 || ! command -v python3 >/dev/null 2>&1; then
  echo "[*] installing openssl / python3 ..."
  apt-get update -qq
  apt-get install -y -qq openssl python3 python3-pip >/dev/null
fi
if ! python3 -c "import jarm" >/dev/null 2>&1; then
  pip3 install --quiet jarm 2>/dev/null \
    || pip3 install --quiet --break-system-packages jarm
fi

echo "====================================================="
echo " target: ${TARGET_IP}:${TARGET_PORT}"
echo "====================================================="

echo "=== SSL cert SHA256 fingerprint ==="
echo | openssl s_client -connect "${TARGET_IP}:${TARGET_PORT}" \
        -servername tls-target.lab 2>/dev/null \
  | openssl x509 -noout -fingerprint -sha256

echo
echo "=== JARM ==="
python3 -m jarm.scanner.scanner "${TARGET_IP}" -p "${TARGET_PORT}"
