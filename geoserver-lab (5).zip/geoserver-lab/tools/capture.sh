#!/usr/bin/env bash
# GeoServer シェルから、4つのビーコン先との通信を tcpdump で観測する。
# 使い方: bash /opt/tools/capture.sh [iface]   (既定 eth0)
command -v tcpdump >/dev/null 2>&1 || { apt-get update -qq && apt-get install -y -qq tcpdump; }
IFACE="${1:-eth0}"
echo "[*] capturing beacon traffic on $IFACE (Ctrl-C to stop)"
exec tcpdump -n -i "$IFACE" \
  'host 172.28.0.50 or host 172.28.0.51 or host 172.28.0.52'
