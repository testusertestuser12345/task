#!/usr/bin/env bash
# ホスト上で 8443/TLS(自己署名=オレオレ) を立てる。
# JARM 値と SSL 証明書ハッシュの供給源。docker 不要・openssl だけで動く。
#
# 使い方:  ./host-tls.sh [PORT]      (既定 8443)
# 停止:    Ctrl-C
set -e

PORT="${1:-8443}"
CERT_DIR="${CERT_DIR:-$HOME/.lab-tls}"
mkdir -p "$CERT_DIR"

# 自己署名証明書を初回だけ生成
if [ ! -f "$CERT_DIR/server.crt" ]; then
  echo "[*] generating self-signed cert ..."
  openssl req -x509 -nodes -newkey rsa:2048 \
    -keyout "$CERT_DIR/server.key" \
    -out    "$CERT_DIR/server.crt" \
    -days 365 \
    -subj "/C=JP/ST=Lab/L=Lab/O=LabCorp/OU=Research/CN=tls-target.lab"
fi

echo "[*] certificate SHA256 fingerprint:"
openssl x509 -in "$CERT_DIR/server.crt" -noout -fingerprint -sha256

echo "[*] listening on 0.0.0.0:${PORT}  (Ctrl-C to stop)"
# 0.0.0.0 で待ち受け → ホストIPへのスキャンで 8443 が見える
exec openssl s_server -accept "${PORT}" \
  -cert "$CERT_DIR/server.crt" -key "$CERT_DIR/server.key" -www
