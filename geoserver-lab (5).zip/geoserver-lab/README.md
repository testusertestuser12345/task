# GeoServer CVE-2024-36401 + トラフィック観測ラボ

隔離ネットワーク内の検証・検出練習用。公開ネットワークに晒さないこと。

## 構成

```
ホスト(Kali)
  :8080 -> geoserver (CVE標的 / Tomcat, /geoserver にUI)
  :8443 -> relay (socat) → RELAY_IP:443 へ中継  ※GeoServerと同一IPで公開

docker labnet 172.28.0.0/24
  geoserver     172.28.0.10   (ip/tcpdump 同梱)
  relay         (netns共有 → .10:8443中継 + 3分ごとRELAY_IPへビーコン)
  traffic-sink  172.28.0.50 / .51 / .52   (1コンテナで3IP, 全TCP受け)
  beacon        (netns共有 → 送信元 .10、内部3IPへ10秒ごと)
```

## 起動

```sh
docker pull docker.osgeo.org/geoserver:2.23.0   # 初回のみ(ベース)
docker compose up -d --build                    # RELAY_IP 既定=40.40.40.44(ラボ内)
```

宛先 40.40.40.44 は docker の専用ネット `extnet(40.40.40.0/24)` 上の traffic-sink。
ホストIPでも実在ホストでもなく、**本物のインターネットには出ずラボ内に閉じる**。
別IPにしたい場合は compose の extnet サブネットと sink の ipv4_address、RELAY_IP を合わせて変更。

- GeoServer UI: http://<host>:8080/geoserver/web  (admin / geoserver)
  - ※ `http://<host>:8080/` が 404 で `/geoserver` で開けるのは**正常**。
    GeoServer は `/geoserver` コンテキストにデプロイされ、ROOT は未割当のため。

## IR/検知シナリオ: socat を kill → 40.40.40.44 通信が止まる

relay コンテナ(socat 同梱イメージ)が起動時に:
- `8443 -> 40.40.40.44:443` の透過中継(socat)を動かす
- **1分ごとに** `40.40.40.10:8443` へ接続 → 中継経由で `40.40.40.44:443` へ転送

これで毎分「8443 → 40.40.40.44」のフローが発生し観測できる。
sink は `40.40.40.44:443` を明示リッスンするので転送は確実に確立。
宛先 40.40.40.44 は extnet(40.40.40.0/24)上のラボ内ホスト。実インターネットには出ない。
relay は GeoServer と PID 名前空間も共有するので socat は **GeoServer の ps** に出る。

```sh
# 観測(GeoServer側から)
docker exec geoserver ps -ef  | grep socat      # socat が見える
docker exec geoserver ss -tnp | grep ':443'     # 40.40.40.44:443 への転送

# ★ 遮断: この socat を kill → 中継が止まり 40.40.40.44 通信が停止(relayは復活しない) ★
docker exec geoserver pkill -x socat

# 検証
docker exec geoserver ss -tn | grep '40.40.40.44' || echo "40.40.40.44 への通信なし"
```

出ない時の切り分け: `docker ps`(relay/traffic-sink が Up か) → `docker logs relay`(entry-beat ログ) →
`docker logs traffic-sink`(":443 でリッスン" が出ているか)。間隔は `BEACON_INT`(既定60秒)。

socketspy / tcpdump 側でも、kill 後に 40.40.40.44 とのセッションが消えるのが観測できる。
前回の socat 未導入は、relay を socat 同梱イメージ(`relay/Dockerfile`)にして解消済み。

## (旧) 8443 中継 + 3分ビーコン

`relay` が GeoServer の .10 で 8443 を待ち受け、`RELAY_IP:443` へ透過TCP中継。
さらに `BEACON_INT`(既定180秒=3分)ごとに `RELAY_IP:443` へ短い通信を出す。

```sh
docker exec -it geoserver bash
  bash /opt/tools/capture.sh            # 8443/443やビーコンをtcpdumpで観測
RELAY_IP=<宛先> BEACON_INT=120 docker compose up -d relay   # 間隔変更
docker compose stop relay
```
- プロセス名は socat のまま(隠蔽なし)。コンテナ名 `relay`。
- relay は GeoServer と **PID名前空間も共有**するので、通信の所有プロセス(PID)が見える:
  ```sh
  docker exec geoserver ps -ef | grep socat          # socat プロセスが並ぶ
  docker exec geoserver ss -tnp | grep ':443'         # 443通信に users:(("socat",pid=...)) が付く
  ```
  socketspy でも同様に PID が解決される。
- RELAY_IP は必ず自分のラボ内の宛先に。未設定だと起動時にエラー。
- 8443はこの中継が使うため、以前の自己署名TLS(tls-sidecar)とは排他。
  ローカル自己署名JARM/証明書を別ポートで残したい場合は host-tls.sh / tls-target を併用。

## GeoServer シェル(ip a / tcpdump は最初から)

```sh
docker exec -it geoserver bash
ip a
bash /opt/tools/capture.sh
```

## 内部ビーコン(.50/.51/.52 へ10秒ごと)

```sh
docker exec geoserver ps aux | grep socat   # beaconはsidecar側(GeoServerに出ない)
docker compose stop beacon
```

## 備考
- `traffic-sink` は NET_ADMIN で IPエイリアス+iptables(全ポート→9999)。
- すべて隔離ラボ内・自分の標的/宛先に対してのみ。
