#!/bin/sh
# lab-relay (isolated lab only): port-forward :8443 -> 40.40.40.44:443 + periodic beacon
set -u

RELAY_IP="${RELAY_IP:-40.40.40.44}"
INT="${BEACON_INT:-120}"
ENTRY="${ENTRY:-40.40.40.10:8443}"

# beacon through the tunnel
( while :; do
    printf 'GET / HTTP/1.0\r\n\r\n' | timeout 5 socat -t3 - "TCP:${ENTRY}" >/dev/null 2>&1
    sleep "$INT"
  done ) &

echo "[*] relay :8443 -> ${RELAY_IP}:443 | beacon every ${INT}s"

# port-forward / tunnel (main socat; kill to stop)
exec socat TCP-LISTEN:8443,fork,reuseaddr "TCP:${RELAY_IP}:443"
