#!/bin/sh
# traffic-sink: labnetで3IP(.50-.52)全TCP受け + extnetで 40.40.40.44 の443を受ける。
set -u

# 172.28.0.50 が付いているIFを特定し、そこに .51/.52 を追加 (計3IP)
LABIF=$(ip -o -4 addr show 2>/dev/null | awk '/172\.28\.0\.50/{print $2; exit}')
LABIF="${LABIF:-eth0}"
for n in 51 52; do
  ip addr add "172.28.0.${n}/24" dev "$LABIF" 2>/dev/null || true
done
echo "[*] addresses:"; ip -br addr show

# relay転送先の 40.40.40.44:443 を明示的に受ける(iptables非依存で確実に確立)
socat TCP-LISTEN:443,fork,reuseaddr OPEN:/dev/null,creat,append &
echo "[*] listening on :443 (relay転送先)"

# 内部の random-port ビーコン用に全TCPを9999へ(iptables使える環境のみ)
iptables -t nat -A PREROUTING -p tcp --dport 1:442   -j REDIRECT --to-ports 9999 2>/dev/null \
  && iptables -t nat -A PREROUTING -p tcp --dport 444:65535 -j REDIRECT --to-ports 9999 2>/dev/null \
  && echo "[*] catch-all REDIRECT -> 9999 enabled (443は除外)" \
  || echo "[!] iptables unavailable: 443以外の閉ポートはRSTになるが通信自体は観測可"

echo "[*] sink listening on :9999"
exec socat TCP-LISTEN:9999,reuseaddr,fork OPEN:/dev/null,creat,append
