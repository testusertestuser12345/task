#!/bin/sh
set -e

# nginx:alpine には openssl が無いので無ければ入れる(ビルド不要運用のため)
command -v openssl >/dev/null 2>&1 || apk add --no-cache openssl

CERT_DIR=/etc/nginx/certs
mkdir -p "$CERT_DIR"

# 自己署名(オレオレ)証明書を初回起動時に生成
if [ ! -f "$CERT_DIR/server.crt" ]; then
  echo "[*] generating self-signed certificate ..."
  openssl req -x509 -nodes -newkey rsa:2048 \
    -keyout "$CERT_DIR/server.key" \
    -out    "$CERT_DIR/server.crt" \
    -days 365 \
    -subj "/C=JP/ST=Lab/L=Lab/O=LabCorp/OU=Research/CN=tls-target.lab"
fi

echo "[*] certificate SHA256 fingerprint:"
openssl x509 -in "$CERT_DIR/server.crt" -noout -fingerprint -sha256

exec nginx -g 'daemon off;'
