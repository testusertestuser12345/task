#!/bin/sh
# beacon サイドカー: GeoServer と netns を共有して動く。
# socat プロセスはこのコンテナ側にあるため GeoServer の ps には出ない。
# 送信元IPは GeoServer(.10) なので GeoServer の tcpdump には "自分の通信" として見える。
#   .50/.51/.52 へ INT 秒ごと・ランダムポートで3本。
set -u

apk add --no-cache socat >/dev/null 2>&1 || true

IPS="172.28.0.50 172.28.0.51 172.28.0.52"
INT="${INT:-10}"

randport(){ awk 'BEGIN{srand();print int(1024+rand()*64511)}'; }

echo "[*] beacon start: 3 flows every ${INT}s (src=GeoServer .10), no process inside GeoServer"
while :; do
  for ip in $IPS; do
    printf 'beacon\n' | timeout 2 socat -t1 - "TCP:${ip}:$(randport)" >/dev/null 2>&1
  done
  sleep "$INT"
done
