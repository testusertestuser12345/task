#!/usr/bin/env bash
# 3) ノイズ処理と小技:
#    (a) soft-404 対策 : /shop/ 以下は存在しないパスも 200 を返す。
#                        --auto-calibration が自動で「偽の200」を学習して除外する。
#    (b) WAF回避       : User-Agent にスキャナ名があると 403。--random-agent で通常ブラウザを装う。
#    (c) 認可バイパス  : admin/ は通常 403 だが X-Forwarded-For: 127.0.0.1 を付けると 200。
#                        -H でヘッダを足し、403 も結果に含めて差を観察する。
#    (d) 遅延検知      : /reports/export は 1.5 秒かかる。--match-time '>1000' で遅いものだけ抽出。
source "$(dirname "$0")/_lib.sh"

echo "== (a)+(b) soft-404 と WAF をいなす =="
ds -u "$TARGET" -e php,html \
   --auto-calibration \
   --random-agent \
   --include-status 200,301,401,403

echo "== (c) X-Forwarded-For で内部限定ゾーンを覗く =="
ds -u "${TARGET}admin/" \
   -H "X-Forwarded-For: 127.0.0.1" \
   -e php --include-status 200,403

echo "== (d) 応答が遅いエンドポイントだけ =="
ds -u "$TARGET" -w "$WORDLISTS_DIR/custom.txt" \
   --match-time ">1000"
