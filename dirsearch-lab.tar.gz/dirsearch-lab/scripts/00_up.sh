#!/usr/bin/env bash
# ラボを起動してビルド、疎通を確認する
set -euo pipefail
cd "$(dirname "$0")/.."
docker compose up -d --build target target-rl proxy1 proxy2 proxy3 proxy-auth proxy-chain
echo "[*] 起動待ち..."; sleep 2
echo -n "[*] target     : "; curl -s -o /dev/null -w '%{http_code}\n' http://localhost:8080/robots.txt
echo -n "[*] target-rl  : "; curl -s -o /dev/null -w '%{http_code}\n' http://localhost:8081/
echo -n "[*] proxy1経由 : "; curl -s -o /dev/null -w '%{http_code}\n' -x http://localhost:3128 http://target:8080/ 2>/dev/null \
  || curl -s -o /dev/null -w '%{http_code}\n' -x http://localhost:3128 http://localhost:8080/
echo "[+] 準備完了。scripts/01_basic.sh などを実行してください。"
echo "    統計:   curl -s http://localhost:8080/_lab/stats"
echo "    リセット: curl -s http://localhost:8080/_lab/reset"
