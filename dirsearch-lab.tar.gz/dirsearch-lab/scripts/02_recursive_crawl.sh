#!/usr/bin/env bash
# 2) 深掘り: 再帰 + クロール + バックアップ探索
#    -r            見つかったディレクトリを再帰的に掘る (api/ -> api/v1/ -> api/v1/users)
#    --crawl       応答内のリンクや robots.txt から新しいパスを発見 (/secret-panel/, /api/v2/internal/debug)
#    --find-backup 見つかったファイルの .bak/.old/~/.zip などを自動で試す (login.php -> login.php.bak)
source "$(dirname "$0")/_lib.sh"

ds -u "$TARGET" \
   -e php,html,js \
   -r -R 3 \
   --crawl \
   --find-backup \
   --random-agent \
   -o /work/02_recursive.json -O json

echo "[+] secret-panel/ (robots由来) や api/v2/internal/debug (JS由来)、login.php.bak が出れば成功"
