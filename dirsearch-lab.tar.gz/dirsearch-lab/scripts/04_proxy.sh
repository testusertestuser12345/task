#!/usr/bin/env bash
# 4) プロキシ経由:
#    (a) 単段        : -p で1つのプロキシを指定
#    (b) ローテーション: -p を複数指定、または --proxies-file で一覧を渡すとリクエストごとにランダムで分散
#                       (dirsearch は複数プロキシを与えると自動でラウンドロビン的に切り替える)
#    (c) 認証つき     : URL に user:pass を埋める or --proxy-auth
#    (d) 多段(チェーン): proxy-chain は受けた要求を proxy2 へ丸ごと転送する。dirsearch からは1ホップに見える。
#    (e) 置換プロキシ : --replay-proxy で「見つかったパスだけ」を別プロキシ(手元のBurp等)で叩き直す
#    (f) SOCKS/Tor   : -p socks5://host:port 、Tor なら --tor (scanner イメージに pysocks 同梱済み)
source "$(dirname "$0")/_lib.sh"

echo "== (a) 単段 proxy1 経由 =="
ds -u "$TARGET" -w "$WORDLISTS_DIR/custom.txt" -p "$PROXY1"

echo "== (b) 3台ローテーション（proxies.txt 経由）=="
ds -u "$TARGET" -w "$WORDLISTS_DIR/custom.txt" \
   --proxies-file "$WORDLISTS_DIR/proxies.txt" \
   --delay 0.05

echo "== (c) Basic認証つきプロキシ =="
ds -u "$TARGET" -w "$WORDLISTS_DIR/custom.txt" -p "$PROXY_AUTH"
#  または:  ds -u "$TARGET" -p http://proxy-auth:3128 --proxy-auth lab:lab123

echo "== (d) 多段チェーン (scanner -> proxy-chain -> proxy2 -> target) =="
ds -u "$TARGET" -w "$WORDLISTS_DIR/custom.txt" -p "$PROXY_CHAIN"

echo "[i] 各コンテナのログで経由を確認:  docker compose logs proxy1 proxy2 proxy-chain"
