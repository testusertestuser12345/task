#!/usr/bin/env bash
# 1) 基本スキャン: デフォルト辞書 + 拡張子展開
#    %EXT% を php,html,js,bak に展開し、簡易テーブルで表示する
source "$(dirname "$0")/_lib.sh"

ds -u "$TARGET" \
   -e php,html,js,bak \
   --random-agent \
   -o /work/01_basic.md -O md

echo "[+] robots.txt / .env / .git/HEAD / backup.zip / swagger.json などが 200 で出れば成功"
