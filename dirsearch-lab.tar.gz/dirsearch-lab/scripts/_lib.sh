#!/usr/bin/env bash
# 共通設定。各スクリプトの冒頭で読み込む。
# dirsearch の呼び出し方を環境で切り替えられるようにしておく。
#
#   DS_MODE=docker (既定) : scanner コンテナを lab-net 上で起動して実行
#                           標的は service 名で解決: target / target-rl / proxy1 ...
#   DS_MODE=local         : ホストに入れた dirsearch をそのまま使う
#                           標的は localhost:8080 など（PORT マッピング経由）
set -euo pipefail
cd "$(dirname "$0")/.."

DS_MODE="${DS_MODE:-docker}"

if [ "$DS_MODE" = "local" ]; then
  TARGET="${TARGET:-http://127.0.0.1:8080/}"
  TARGET_RL="${TARGET_RL:-http://127.0.0.1:8081/}"
  PROXY1="${PROXY1:-http://127.0.0.1:3128}"
  PROXY2="${PROXY2:-http://127.0.0.1:3129}"
  PROXY3="${PROXY3:-http://127.0.0.1:3130}"
  PROXY_AUTH="${PROXY_AUTH:-http://lab:lab123@127.0.0.1:3131}"
  PROXY_CHAIN="${PROXY_CHAIN:-http://127.0.0.1:3132}"
  WORDLISTS_DIR="${WORDLISTS_DIR:-$PWD/wordlists}"
  ds() { dirsearch "$@"; }
else
  # コンテナ内から見たアドレス（compose の service 名 / 固定IP）
  TARGET="${TARGET:-http://target:8080/}"
  TARGET_RL="${TARGET_RL:-http://target-rl:8080/}"
  PROXY1="${PROXY1:-http://proxy1:3128}"
  PROXY2="${PROXY2:-http://proxy2:3128}"
  PROXY3="${PROXY3:-http://proxy3:3128}"
  PROXY_AUTH="${PROXY_AUTH:-http://lab:lab123@proxy-auth:3128}"
  PROXY_CHAIN="${PROXY_CHAIN:-http://proxy-chain:3128}"
  WORDLISTS_DIR="${WORDLISTS_DIR:-/wordlists}"
  ds() { docker compose --profile tools run --rm -T dirsearch "$@"; }
fi

echo "[*] DS_MODE=$DS_MODE  TARGET=$TARGET"
