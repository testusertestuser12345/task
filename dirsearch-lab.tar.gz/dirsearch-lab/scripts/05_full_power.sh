#!/usr/bin/env bash
# 5) 「最強」合わせ技 — 隠れ方・探し方・残し方を全部盛り
#    発見力  : カテゴリ辞書(all) + 拡張子 + 再帰 + クロール + バックアップ探索
#    静かさ  : 非同期(-a) だが --max-rate で秒間を抑え、--random-agent + --delay で平準化
#    回避    : --auto-calibration(soft-404除外)、--proxies-file(分散)
#    証跡    : 複数フォーマット同時出力 + マッチした生レスポンスを保存
source "$(dirname "$0")/_lib.sh"
mkdir -p reports

ds -u "$TARGET" \
   --wordlist-categories all \
   -e php,html,js,json,bak,old,zip,sql \
   -a -t 30 --max-rate 40 --delay 0.03 \
   -r -R 3 --crawl --find-backup \
   --auto-calibration \
   --random-agent \
   --proxies-file "$WORDLISTS_DIR/proxies.txt" \
   --include-status 200,204,301,302,307,401,403 \
   --exclude-sizes 0B \
   -o /work/full.md     -O md \
   -o /work/full.json   -O json \
   -o /work/full.sqlite -O sqlite \
   --save-response /work/responses

echo "[+] reports/ に md/json/sqlite と responses/（生レスポンス）が残る"
