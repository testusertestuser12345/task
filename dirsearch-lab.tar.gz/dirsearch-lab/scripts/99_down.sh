#!/usr/bin/env bash
# ラボを停止・片付け
set -euo pipefail
cd "$(dirname "$0")/.."
docker compose --profile tools down -v --remove-orphans
echo "[+] 停止しました。"
