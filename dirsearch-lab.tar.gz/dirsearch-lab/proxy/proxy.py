#!/usr/bin/env python3
"""
デモ用の簡易フォワードプロキシ（標準ライブラリのみ）
  - 通常のHTTPプロキシ（GET http://host/path ...）
  - CONNECT トンネル（HTTPS や proxychains の http チェーンで使用）
  - 任意で Basic 認証（PROXY_USER / PROXY_PASS）
  - 任意で上流プロキシへの多段転送（UPSTREAM=host:port）
  - 経由したリクエストをログ出力

※ 学習・デモ専用。インターネットに公開しないこと。
"""
import base64
import os
import select
import socket
import sys
import threading
from urllib.parse import urlsplit

NAME = os.environ.get("PROXY_NAME", "proxy")
PORT = int(os.environ.get("PORT", "3128"))
USER = os.environ.get("PROXY_USER", "")
PASS = os.environ.get("PROXY_PASS", "")
UPSTREAM = os.environ.get("UPSTREAM", "")  # 例: proxy2:3128
QUIET = os.environ.get("QUIET", "0") == "1"
SOURCE_IP = os.environ.get("SOURCE_IP", "")  # 送信元IPを固定したい時（通常は空でOK）
BUF = 65536


def connect(host, port):
    src = (SOURCE_IP, 0) if SOURCE_IP else None
    return socket.create_connection((host, int(port)), timeout=10, source_address=src)


def log(msg):
    if not QUIET:
        sys.stdout.write(f"[{NAME}] {msg}\n")
        sys.stdout.flush()


def read_head(sock):
    data = b""
    while b"\r\n\r\n" not in data:
        chunk = sock.recv(BUF)
        if not chunk:
            return None, b""
        data += chunk
        if len(data) > 1 << 20:
            return None, b""
    head, rest = data.split(b"\r\n\r\n", 1)
    return head.decode("latin-1"), rest


def pipe(a, b):
    socks = [a, b]
    try:
        while True:
            r, _, x = select.select(socks, [], socks, 60)
            if x or not r:
                return
            for s in r:
                data = s.recv(BUF)
                if not data:
                    return
                (b if s is a else a).sendall(data)
    except OSError:
        return


def authorized(headers):
    if not USER:
        return True
    want = "Basic " + base64.b64encode(f"{USER}:{PASS}".encode()).decode()
    return headers.get("proxy-authorization", "") == want


def handle(client, addr):
    try:
        head, rest = read_head(client)
        if not head:
            return
        lines = head.split("\r\n")
        method, target, version = lines[0].split(" ", 2)
        headers = {}
        for line in lines[1:]:
            if ":" in line:
                k, v = line.split(":", 1)
                headers[k.strip().lower()] = v.strip()

        if not authorized(headers):
            client.sendall(b"HTTP/1.1 407 Proxy Authentication Required\r\n"
                           b"Proxy-Authenticate: Basic realm=\"lab\"\r\nContent-Length: 0\r\n\r\n")
            log(f"{addr[0]} 407 {method} {target}")
            return

        if UPSTREAM:
            # 多段: 受け取った要求をそのまま上流プロキシへ（認証ヘッダは外す）
            uh, up = UPSTREAM.split(":")
            upstream = connect(uh, up)
            fwd = [lines[0]] + [l for l in lines[1:] if not l.lower().startswith("proxy-authorization")]
            upstream.sendall(("\r\n".join(fwd) + "\r\n\r\n").encode("latin-1") + rest)
            log(f"{addr[0]} -> {UPSTREAM} {method} {target}")
            pipe(client, upstream)
            upstream.close()
            return

        if method.upper() == "CONNECT":
            host, port = target.rsplit(":", 1)
            remote = connect(host, port)
            client.sendall(b"HTTP/1.1 200 Connection established\r\n\r\n")
            log(f"{addr[0]} CONNECT {target}")
            if rest:
                remote.sendall(rest)
            pipe(client, remote)
            remote.close()
            return

        # 通常の HTTP プロキシ要求（絶対URI）
        u = urlsplit(target)
        host, port = u.hostname, u.port or 80
        path = (u.path or "/") + (("?" + u.query) if u.query else "")
        out = [f"{method} {path} {version}"]
        for line in lines[1:]:
            low = line.lower()
            if low.startswith(("proxy-authorization", "proxy-connection", "connection", "keep-alive")):
                continue
            out.append(line)
        out.append("Connection: close")  # 1接続1リクエストにしてログを分かりやすく
        remote = connect(host, port)
        remote.sendall(("\r\n".join(out) + "\r\n\r\n").encode("latin-1") + rest)
        log(f"{addr[0]} {method} {target}")
        pipe(client, remote)
        remote.close()
    except Exception as e:  # デモ用なので握りつぶしてログだけ
        try:
            client.sendall(b"HTTP/1.1 502 Bad Gateway\r\nContent-Length: 0\r\n\r\n")
        except OSError:
            pass
        log(f"{addr[0]} error: {e}")
    finally:
        client.close()


def main():
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("0.0.0.0", PORT))
    srv.listen(512)
    log(f"listening on :{PORT} auth={'on' if USER else 'off'} upstream={UPSTREAM or '-'}")
    while True:
        c, a = srv.accept()
        threading.Thread(target=handle, args=(c, a), daemon=True).start()


if __name__ == "__main__":
    main()
