# GeoServer CVE-2024-36401 + トラフィック観測ラボ

隔離ネットワーク内の検証・検出練習用。公開ネットワークに晒さないこと。

## 構成

```
ホスト(Kali)
  :8080 -> geoserver (CVE標的 / Tomcat)
  :8443 -> tls-sidecar (自己署名TLS, JARM/証明書ハッシュ源)  ※GeoServerと同一IPで公開

docker labnet 172.28.0.0/24
  geoserver     172.28.0.10   (ip/tcpdump 同梱)
  tls-sidecar   (netns共有 → 8443 を .10 で提供)
  traffic-sink  172.28.0.50 / .51 / .52   (1コンテナで3IP, 全TCP受け)
  beacon        (netns共有 → 送信元 .10、プロセスはGeoServerに出ない)

beacon -> .50/.51/.52 へ socat 3本 (10秒ごと・ランダムポート)
```

## 起動

```sh
docker pull docker.osgeo.org/geoserver:2.23.0   # 初回のみ(ベース取得, 遅い)
docker compose up -d --build                    # ip/tcpdump入りの派生イメージをビルド
```

- GeoServer: http://localhost:8080/geoserver/web  (admin / geoserver)
- TLS:       https://localhost:8443/  (自己署名)

## スキャン(ホストIP)

```sh
nmap -p 8080,8443 <ホストIP>        # 両方 open
echo | openssl s_client -connect <ホストIP>:8443 2>/dev/null | openssl x509 -noout -fingerprint -sha256
python3 -m jarm.scanner.scanner <ホストIP> -p 8443
```

## GeoServer シェル(ip a / tcpdump は最初から使える)

```sh
docker exec -it geoserver bash
ip a                                 # 172.28.0.10 を確認(インストール不要)
bash /opt/tools/capture.sh           # .50/.51/.52 が約10秒周期・毎回別ポートで出る
```

## ビーコン(プロセスはGeoServerに出ない)

```sh
docker exec geoserver ps aux | grep socat    # → 何も出ない(プロセスなし)
docker compose stop beacon                   # 止める / start で再開
INT=5 docker compose up -d beacon            # 間隔変更(秒)
```

## 備考
- 8443 は `tls-sidecar` コンテナが提供（GeoServerとnetns共有なので同じホストIPで見える）。
  ホスト直で立てたい場合の `host-tls.sh` も同梱（その場合は compose の tls-sidecar を外す）。
- `traffic-sink` は NET_ADMIN で IPエイリアス+iptables(全ポート→9999)。iptables不可環境では
  閉ポートRSTになるが通信自体は観測可能。
- すべて隔離ラボ内・自分の標的に対してのみ。
