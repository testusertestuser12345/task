#!/bin/sh
# traffic-sink: 1コンテナで4つのIP(.50-.53)を持ち、全TCPポートを受ける。
# GeoServer からのランダムポート接続が成立し、"4つのIPと通信" に見える。
set -u

# 必要ツール(初回のみ)。Kali側はネット可なので取得できる。
apk add --no-cache socat iproute2 iptables >/dev/null 2>&1 || true

# 追加IPエイリアス → 計3IP (.50 は compose で付与済み)
for n in 51 52; do
  ip addr add "172.28.0.${n}/24" dev eth0 2>/dev/null || true
done
echo "[*] addresses on eth0:"; ip -br addr show eth0

# 全TCPポートを 9999 へリダイレクト → どんなランダムポートでも接続確立
iptables -t nat -A PREROUTING -p tcp -j REDIRECT --to-ports 9999 2>/dev/null \
  && echo "[*] catch-all REDIRECT -> 9999 enabled" \
  || echo "[!] iptables unavailable: 閉じたポートはRSTになるが通信自体は観測可"

# 受け口(受信データは破棄)
echo "[*] sink listening on :9999"
exec socat TCP-LISTEN:9999,reuseaddr,fork OPEN:/dev/null,creat,append
