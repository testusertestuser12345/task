#!/bin/bash
# sshd と tinyproxy を両方起動
set -e
echo "[bastion] starting sshd..."
/usr/sbin/sshd
echo "[bastion] starting tinyproxy (foreground)..."
exec tinyproxy -d
