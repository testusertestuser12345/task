$ORIGIN com.
$TTL 60
@       IN  SOA dns.com. admin.com. (
                2026102001 ; serial
                3600       ; refresh
                600        ; retry
                86400      ; expire
                60 )       ; minimum
@       IN  NS  dns.com.

; --- 各サーバーの A レコード ---
dns         IN  A   100.100.100.53
one         IN  A   10.10.10.10
; app02 は FQDN 2つ (同じ 20.20.20.20 を指す)
two         IN  A   20.20.20.20
twenty      IN  A   20.20.20.20
; db03 は FQDN なし → レコード書かない (30.30.30.30)
; web04 は 2つのIPを持ち、FQDN は four.com 1つ → マルチAレコード
four        IN  A   40.40.40.40
four        IN  A   50.50.50.50
six         IN  A   60.60.60.60
seven       IN  A   70.70.70.70
eight       IN  A   80.80.80.80
nine        IN  A   90.90.90.90
hundred     IN  A   100.100.100.100
