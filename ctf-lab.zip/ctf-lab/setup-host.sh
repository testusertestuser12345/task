#!/usr/bin/env bash
# =============================================================
# kali (ホスト) 側のセットアップ補助
#   1) コンテナを起動
#   2) ホストの名前解決を CoreDNS (100.100.100.53) に向ける
# =============================================================
set -e

echo "[*] コンテナ起動..."
docker compose up -d

echo "[*] 起動待ち (5秒)"; sleep 5
docker compose ps

echo
echo "[*] ホストから *.com を引けるようにします"
echo "    方法A (おすすめ・恒久): /etc/resolv.conf に 100.100.100.53 を追加"
echo "    方法B (手軽・一時):     下記のように dig で直接指定して確認"
echo
echo "    例) dig @100.100.100.53 one.com +short"
echo "    例) curl http://10.10.10.10"
echo "    例) curl -u user:password http://100.100.100.100"
echo
echo "[*] ホストの resolv.conf に追記する場合 (root):"
echo "      echo 'nameserver 100.100.100.53' | sudo tee -a /etc/resolv.conf"
echo
echo "[完了] docker compose ps で 10台すべて Up になっていれば成功"
