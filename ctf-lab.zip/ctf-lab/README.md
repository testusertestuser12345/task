# CTF / ネットワーク構成 学習ラボ (Docker)

コンテナ **10台** / サブネット **10個** / 各コンテナに **固定IP**。
kali(ホスト)から全コンテナへ到達できます。

## 使い方 (kaliホストで)
```bash
cd ctf-lab
docker compose up -d        # 10台起動
docker compose ps           # 状態確認
```

ホストから FQDN を引く場合:
```bash
dig @100.100.100.53 one.com +short        # まず単発で確認
echo 'nameserver 100.100.100.53' | sudo tee -a /etc/resolv.conf   # 恒久化
```

## 構成一覧
| # | コンテナ | 役割 | IP | FQDN | ポート |
|---|---------|------|-----|------|------|
| 1 | web01 | nginx HTTP | 10.10.10.10 | one.com | 80 |
| 2 | app02 | nginx HTTPS | 20.20.20.20 | two.com, twenty.com | 443 |
| 3 | db03  | MariaDB | 30.30.30.30 | (なし) | 3306 |
| 4 | web04 | nginx HTTPS / 2NIC | 40.40.40.40 + 50.50.50.50 | four.com | 443 |
| 5 | web06 | nginx | 60.60.60.60 | six.com | 80 |
| 6 | web07 | nginx | 70.70.70.70 | seven.com | 80 |
| 7 | web08 | nginx | 80.80.80.80 | eight.com | 80 |
| 8 | web09 | nginx | 90.90.90.90 | nine.com | 80 |
| 9 | proxy | reverse proxy + Basic認証 | 100.100.100.100 | hundred.com | 80 |
| 10| dns   | CoreDNS | 100.100.100.53 (+各ネット .53) | dns.com | 53 |

- proxy の認証: **user / password** 。`curl -u user:password http://100.100.100.100`
- db03 の認証: root=`rootpass` / user=`ctf` pass=`ctfpass` db=`ctfdb`
- DNS: `*.com` を担当、それ以外は 8.8.8.8 へ転送

## 動作確認コマンド
```bash
curl http://10.10.10.10                         # web01
curl -k https://20.20.20.20                     # app02
curl -u user:password http://100.100.100.100    # proxy → web01 に中継
dig @100.100.100.53 four.com +short             # 40 と 50 両方返る
```

## 学習ポイント
- **複数サブネット設計** … 10個の /24 を分離
- **固定IP割当て** … ipam で static IP
- **マルチNIC (web04, proxy, dns)** … 複数ネットにまたがる = ルーティング/pivot
- **DNS** … Aレコード、マルチAレコード、FQDNなしホスト
- **リバースプロキシ + Basic認証** … 多段アクセス
