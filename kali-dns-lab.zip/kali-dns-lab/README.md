# Kali DNS ラボ

## 準備（初回のみ）
```bash
sudo apt update && sudo apt install -y docker.io docker-compose-plugin
sudo systemctl enable --now docker
sudo usermod -aG docker $USER   # 一度ログアウト→ログイン
```

## 起動・確認・停止
```bash
unzip kali-dns-lab.zip && cd kali-dns-lab
chmod +x lab.sh
./lab.sh up      # 起動
./lab.sh test    # 正引き・逆引き・HTTPの確認
./lab.sh down    # 停止
```

## 構成（172.30.0.0/24）
| パターン | FQDN | IP（逆引きも同じ対応） | サーバ |
|---|---|---|---|
| DNS | dns.test | 172.30.0.53 | CoreDNS |
| 1対1 | one.test | .11 | nginx |
| 1対1 | two.test | .12 | apache |
| FQDN1つにIP2つ | three.test | .13 / .14 | nginx / apache |
| FQDN1つにIP3つ | four.test | .15 / .16 / .17 | nginx / apache / caddy |
| IP1つにFQDN2つ | five.test, six.test | .18 | nginx（仮想ホスト） |
| テスト用 | seven.test | .100 | client（dig/curl） |

## Kali本体から直接使う
```bash
dig @172.30.0.53 four.test           # 正引き
dig @172.30.0.53 -x 172.30.0.18      # 逆引き
./lab.sh kali-dns-on                 # Kaliのresolverをラボ向けに
curl http://five.test
./lab.sh kali-dns-off                # 元に戻す
```

## レコードを追加したいとき
- 正引き: `dns/db.test` に1行（例 `eight IN A 172.30.0.19`）
- 逆引き: `dns/db.172.30.0` に1行（例 `19 IN PTR eight.test.`）
- 両ファイルの serial を1つ増やす（数秒で自動反映）
