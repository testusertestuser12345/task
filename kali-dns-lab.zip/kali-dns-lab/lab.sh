#!/usr/bin/env bash
# 使い方: ./lab.sh up | down | test | kali-dns-on | kali-dns-off
set -e
cd "$(dirname "$0")"

case "$1" in
  up)
    docker compose up -d
    echo "起動しました。 ./lab.sh test で確認できます"
    ;;
  down)
    docker compose down
    ;;
  test)
    echo "######## 正引き ########"
    for n in dns one two three four five six seven; do
      printf "%-12s -> " "$n.test"
      docker exec client dig +short $n.test | tr '\n' ' '; echo
    done
    echo "######## 逆引き ########"
    for i in 53 11 12 13 14 15 16 17 18 100; do
      printf "%-14s -> " "172.30.0.$i"
      docker exec client dig +short -x 172.30.0.$i | tr '\n' ' '; echo
    done
    echo "######## HTTP ########"
    echo "-- four.test を3回（違うサーバに当たる）"
    for i in 1 2 3; do docker exec client curl -s http://four.test; done
    echo "-- 同じIPで名前違い"
    docker exec client curl -s http://five.test
    docker exec client curl -s http://six.test
    ;;
  kali-dns-on)
    # Kali本体からもFQDNで引けるようにする（元の設定はバックアップ）
    sudo cp /etc/resolv.conf /etc/resolv.conf.lab-bak
    echo -e "nameserver 172.30.0.53\nsearch test" | sudo tee /etc/resolv.conf
    ;;
  kali-dns-off)
    sudo cp /etc/resolv.conf.lab-bak /etc/resolv.conf && echo "元に戻しました"
    ;;
  *)
    echo "使い方: $0 {up|down|test|kali-dns-on|kali-dns-off}"
    ;;
esac
